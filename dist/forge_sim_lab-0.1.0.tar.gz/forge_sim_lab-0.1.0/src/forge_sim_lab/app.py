from __future__ import annotations

import json
import queue
import threading
import traceback
from copy import deepcopy
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .config import AppDefaults, DEFAULT_FORMATS, MAX_DECK_SLOTS
from .forge import build_forge_command, run_simulation
from .league import run_league_batch
from .models import SimulationConfig, SimulationResult

APP_DEFAULTS = AppDefaults()


class ForgeSimLabApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Forge Sim Lab")
        self.root.geometry("1180x860")

        self.message_queue: queue.Queue[tuple[str, object]] = queue.Queue()
        self.worker_thread: threading.Thread | None = None

        self.jar_var = tk.StringVar()
        self.deck_dir_var = tk.StringVar()
        self.output_dir_var = tk.StringVar(value=str(APP_DEFAULTS.base_output_directory))
        self.java_var = tk.StringVar(value=APP_DEFAULTS.java_executable)
        self.format_var = tk.StringVar(value=APP_DEFAULTS.format_name)
        self.games_var = tk.StringVar(value=str(APP_DEFAULTS.game_count))
        self.matches_var = tk.StringVar(value=str(APP_DEFAULTS.match_count))
        self.player_count_var = tk.StringVar(value="")
        self.timeout_var = tk.StringVar(value=str(APP_DEFAULTS.timeout_seconds))
        self.repetitions_var = tk.StringVar(value=str(APP_DEFAULTS.repetitions))
        self.clock_var = tk.StringVar(value="")
        self.quiet_var = tk.BooleanVar(value=APP_DEFAULTS.quiet)
        self.tournament_var = tk.BooleanVar(value=APP_DEFAULTS.tournament)
        self.extra_args_var = tk.StringVar()

        self.deck_vars: list[tk.StringVar] = [tk.StringVar() for _ in range(MAX_DECK_SLOTS)]

        self._build_ui()
        self._poll_queue()

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=10)
        outer.pack(fill="both", expand=True)

        top = ttk.LabelFrame(outer, text="Forge / Java / Output", padding=10)
        top.pack(fill="x", pady=(0, 10))

        self._path_row(top, 0, "Forge JAR", self.jar_var, self._browse_jar)
        self._path_row(top, 1, "Deck Directory", self.deck_dir_var, self._browse_deck_dir)
        self._path_row(top, 2, "Output Directory", self.output_dir_var, self._browse_output_dir)

        ttk.Label(top, text="Java").grid(row=3, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(top, textvariable=self.java_var, width=40).grid(row=3, column=1, sticky="ew", pady=4)
        top.columnconfigure(1, weight=1)

        settings = ttk.LabelFrame(outer, text="Simulation Settings", padding=10)
        settings.pack(fill="x", pady=(0, 10))

        format_combo = ttk.Combobox(settings, textvariable=self.format_var, values=DEFAULT_FORMATS, width=16)
        format_combo["state"] = "normal"

        entries = [
            ("Format", format_combo),
            ("Games", ttk.Entry(settings, textvariable=self.games_var, width=12)),
            ("Matches", ttk.Entry(settings, textvariable=self.matches_var, width=12)),
            ("Player Count", ttk.Entry(settings, textvariable=self.player_count_var, width=12)),
            ("Clock (sec)", ttk.Entry(settings, textvariable=self.clock_var, width=12)),
            ("Timeout (sec)", ttk.Entry(settings, textvariable=self.timeout_var, width=12)),
            ("Batch Repetitions", ttk.Entry(settings, textvariable=self.repetitions_var, width=12)),
        ]

        for column, (label, widget) in enumerate(entries):
            ttk.Label(settings, text=label).grid(row=0, column=column * 2, sticky="w", padx=(0, 6), pady=4)
            widget.grid(row=0, column=column * 2 + 1, sticky="w", padx=(0, 12), pady=4)

        ttk.Checkbutton(settings, text="Quiet (-q)", variable=self.quiet_var).grid(row=1, column=0, sticky="w", pady=6)
        ttk.Checkbutton(settings, text="Tournament (-t)", variable=self.tournament_var).grid(row=1, column=1, sticky="w", pady=6)

        ttk.Label(settings, text="Extra Args").grid(row=1, column=2, sticky="w", pady=6)
        ttk.Entry(settings, textvariable=self.extra_args_var, width=70).grid(row=1, column=3, columnspan=8, sticky="ew", pady=6)
        settings.columnconfigure(9, weight=1)

        decks_frame = ttk.LabelFrame(outer, text="Deck Inputs (2-12)", padding=10)
        decks_frame.pack(fill="both", expand=False, pady=(0, 10))

        for index, var in enumerate(self.deck_vars, start=1):
            row = index - 1
            ttk.Label(decks_frame, text=f"Deck {index}").grid(row=row, column=0, sticky="w", padx=(0, 8), pady=2)
            ttk.Entry(decks_frame, textvariable=var, width=110).grid(row=row, column=1, sticky="ew", pady=2)
            ttk.Button(
                decks_frame,
                text="Browse",
                command=lambda current=var: self._browse_deck_file(current),
            ).grid(row=row, column=2, padx=(8, 0), pady=2)

        decks_frame.columnconfigure(1, weight=1)

        buttons = ttk.Frame(outer)
        buttons.pack(fill="x", pady=(0, 10))

        ttk.Button(buttons, text="Preview Command", command=self.preview_command).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Run Single Sim", command=self.run_single).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Run Batch / League", command=self.run_batch).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Clear Decks", command=self.clear_decks).pack(side="left", padx=(0, 8))

        logs = ttk.LabelFrame(outer, text="Output", padding=10)
        logs.pack(fill="both", expand=True)

        self.output_text = tk.Text(logs, wrap="word", font=("Courier New", 10))
        self.output_text.pack(fill="both", expand=True)

    def _path_row(self, parent: ttk.Widget, row: int, label: str, variable: tk.StringVar, command) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(parent, textvariable=variable, width=110).grid(row=row, column=1, sticky="ew", pady=4)
        ttk.Button(parent, text="Browse", command=command).grid(row=row, column=2, padx=(8, 0), pady=4)

    def _browse_jar(self) -> None:
        path = filedialog.askopenfilename(title="Choose forge.jar", filetypes=[("JAR Files", "*.jar"), ("All Files", "*.*")])
        if path:
            self.jar_var.set(path)

    def _browse_deck_dir(self) -> None:
        path = filedialog.askdirectory(title="Choose deck directory")
        if path:
            self.deck_dir_var.set(path)

    def _browse_output_dir(self) -> None:
        path = filedialog.askdirectory(title="Choose output directory")
        if path:
            self.output_dir_var.set(path)

    def _browse_deck_file(self, target_var: tk.StringVar) -> None:
        path = filedialog.askopenfilename(title="Choose deck file", filetypes=[("Deck Files", "*.dck"), ("All Files", "*.*")])
        if path:
            target_var.set(path)

    def clear_decks(self) -> None:
        for var in self.deck_vars:
            var.set("")

    def _collect_config(self, with_output_stamp: bool = True) -> SimulationConfig:
        jar_value = self.jar_var.get().strip()
        if not jar_value:
            raise ValueError("Forge JAR is required.")

        decks = [var.get().strip() for var in self.deck_vars if var.get().strip()]
        if len(decks) < 2:
            raise ValueError("Please provide at least two decks.")
        if len(decks) > MAX_DECK_SLOTS:
            raise ValueError(f"This UI supports at most {MAX_DECK_SLOTS} decks.")

        output_root = Path(self.output_dir_var.get().strip() or str(APP_DEFAULTS.base_output_directory))
        output_dir = output_root / datetime.now().strftime("%Y%m%d_%H%M%S") if with_output_stamp else output_root

        extra_args = self.extra_args_var.get().strip().split() if self.extra_args_var.get().strip() else []

        player_count = int(self.player_count_var.get()) if self.player_count_var.get().strip() else None
        clock = int(self.clock_var.get()) if self.clock_var.get().strip() else None
        deck_dir = Path(self.deck_dir_var.get().strip()) if self.deck_dir_var.get().strip() else None

        return SimulationConfig(
            forge_jar=Path(jar_value),
            decks=decks,
            deck_directory=deck_dir,
            game_count=int(self.games_var.get()),
            match_count=int(self.matches_var.get()) if self.matches_var.get().strip() else None,
            format_name=self.format_var.get().strip(),
            player_count=player_count,
            tournament=self.tournament_var.get(),
            quiet=self.quiet_var.get(),
            timeout_seconds=int(self.timeout_var.get()),
            java_executable=self.java_var.get().strip() or "java",
            clock_seconds=clock,
            output_directory=output_dir,
            extra_args=extra_args,
        )

    def preview_command(self) -> None:
        try:
            config = self._collect_config()
            command = build_forge_command(config)
        except Exception as exc:
            messagebox.showerror("Invalid configuration", str(exc))
            return

        self._append_output("$ " + " ".join(command) + "\n")

    def run_single(self) -> None:
        self._start_background_job(self._run_single_worker)

    def run_batch(self) -> None:
        self._start_background_job(self._run_batch_worker)

    def _start_background_job(self, target) -> None:
        if self.worker_thread and self.worker_thread.is_alive():
            messagebox.showinfo("Busy", "A simulation job is already running.")
            return

        self.worker_thread = threading.Thread(target=target, daemon=True)
        self.worker_thread.start()

    def _run_single_worker(self) -> None:
        try:
            config = self._collect_config()
            self.message_queue.put(("log", "Running single simulation...\n"))
            self.message_queue.put(("log", "$ " + " ".join(build_forge_command(config)) + "\n\n"))
            result = run_simulation(config)
            self.message_queue.put(("single_result", result))
        except Exception as exc:
            self.message_queue.put(("error", f"{exc}\n{traceback.format_exc()}"))

    def _run_batch_worker(self) -> None:
        try:
            config = self._collect_config(with_output_stamp=False)
            repetitions = int(self.repetitions_var.get())
            batch_root = Path(self.output_dir_var.get().strip() or str(APP_DEFAULTS.base_output_directory)) / datetime.now().strftime("batch_%Y%m%d_%H%M%S")
            preview_config = deepcopy(config)
            preview_config.output_directory = None
            self.message_queue.put(("log", f"Running batch with {repetitions} repetitions...\n"))
            self.message_queue.put(("log", "$ " + " ".join(build_forge_command(preview_config)) + "\n\n"))
            _, summary = run_league_batch(config, repetitions=repetitions, root_output_directory=batch_root)
            self.message_queue.put(("batch_result", (batch_root, summary.to_jsonable())))
        except Exception as exc:
            self.message_queue.put(("error", f"{exc}\n{traceback.format_exc()}"))

    def _poll_queue(self) -> None:
        try:
            while True:
                kind, payload = self.message_queue.get_nowait()
                if kind == "log":
                    self._append_output(str(payload))
                elif kind == "single_result":
                    self._handle_single_result(payload)  # type: ignore[arg-type]
                elif kind == "batch_result":
                    batch_root, summary = payload  # type: ignore[misc]
                    self._append_output(f"Batch complete.\nOutput directory: {batch_root}\n")
                    self._append_output(json.dumps(summary, indent=2) + "\n\n")
                elif kind == "error":
                    self._append_output("ERROR:\n" + str(payload) + "\n")
                    messagebox.showerror("Simulation Error", str(payload))
        except queue.Empty:
            pass

        self.root.after(150, self._poll_queue)

    def _handle_single_result(self, result: SimulationResult) -> None:
        self._append_output("Single simulation complete.\n")
        self._append_output(f"Return code: {result.return_code}\n")
        self._append_output(f"Duration: {result.duration_seconds:.2f}s\n")
        self._append_output(f"Winners: {result.winners}\n")
        self._append_output(f"Output directory: {result.config.output_directory}\n\n")
        self._append_output("STDOUT\n------\n")
        self._append_output(result.stdout + "\n")
        if result.stderr.strip():
            self._append_output("\nSTDERR\n------\n")
            self._append_output(result.stderr + "\n")
        self._append_output("\n")

    def _append_output(self, text: str) -> None:
        self.output_text.insert("end", text)
        self.output_text.see("end")


def launch() -> None:
    root = tk.Tk()
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    ForgeSimLabApp(root)
    root.mainloop()
