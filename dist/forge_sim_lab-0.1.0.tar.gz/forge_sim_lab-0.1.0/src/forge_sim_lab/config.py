from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


DEFAULT_FORMATS = [
    "commander",
    "constructed",
    "standard",
    "modern",
    "legacy",
    "vintage",
    "pioneer",
    "brawl",
]

MAX_DECK_SLOTS = 12


@dataclass(slots=True)
class AppDefaults:
    java_executable: str = "java"
    timeout_seconds: int = 300
    game_count: int = 1
    match_count: int = 1
    repetitions: int = 10
    format_name: str = "commander"
    quiet: bool = True
    tournament: bool = False
    base_output_directory: Path = Path.cwd() / "forge_sim_lab_runs"
