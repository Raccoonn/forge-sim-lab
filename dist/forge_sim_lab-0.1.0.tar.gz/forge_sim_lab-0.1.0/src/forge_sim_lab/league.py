from __future__ import annotations

import json
from collections import Counter
from copy import deepcopy
from datetime import datetime
from pathlib import Path

from .forge import run_simulation
from .models import LeagueSummary, SimulationConfig, SimulationResult


def timestamp_slug() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def run_league_batch(
    base_config: SimulationConfig,
    repetitions: int,
    root_output_directory: Path,
) -> tuple[list[SimulationResult], LeagueSummary]:
    if repetitions < 1:
        raise ValueError("repetitions must be at least 1")

    root_output_directory.mkdir(parents=True, exist_ok=True)

    results: list[SimulationResult] = []
    winner_counts: Counter[str] = Counter()
    return_codes: Counter[str] = Counter()
    run_directories: list[str] = []

    jsonl_path = root_output_directory / "results.jsonl"

    with jsonl_path.open("w", encoding="utf-8") as handle:
        for index in range(1, repetitions + 1):
            config = deepcopy(base_config)
            run_dir = root_output_directory / f"run_{index:04d}"
            config.output_directory = run_dir

            result = run_simulation(config)
            results.append(result)
            run_directories.append(str(run_dir))
            return_codes[str(result.return_code)] += 1

            if result.winners:
                for winner in result.winners:
                    winner_counts[winner] += 1

            handle.write(json.dumps(result.to_jsonable()) + "\n")

    summary = LeagueSummary(
        total_runs=repetitions,
        successful_runs=sum(1 for item in results if item.return_code == 0),
        failed_runs=sum(1 for item in results if item.return_code != 0),
        winner_counts=dict(winner_counts),
        return_codes=dict(return_codes),
        run_directories=run_directories,
    )

    (root_output_directory / "summary.json").write_text(
        json.dumps(summary.to_jsonable(), indent=2),
        encoding="utf-8",
    )

    return results, summary
