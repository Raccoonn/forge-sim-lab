from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path

from .models import SimulationConfig, SimulationResult
from .parser import parse_winners


def build_forge_command(config: SimulationConfig) -> list[str]:
    if len(config.decks) < 2:
        raise ValueError("At least two decks are required.")
    if len(config.decks) > 12:
        raise ValueError("This app currently supports up to 12 decks in one run.")

    command: list[str] = [
        config.java_executable,
        "-jar",
        str(config.forge_jar),
        "sim",
    ]

    for deck in config.decks:
        command.extend(["-d", deck])

    if config.deck_directory:
        command.extend(["-D", str(config.deck_directory)])

    if config.game_count:
        command.extend(["-n", str(config.game_count)])

    if config.match_count:
        command.extend(["-m", str(config.match_count)])

    if config.format_name:
        command.extend(["-f", config.format_name])

    if config.player_count:
        command.extend(["-p", str(config.player_count)])

    if config.clock_seconds:
        command.extend(["-c", str(config.clock_seconds)])

    if config.quiet:
        command.append("-q")

    if config.tournament:
        command.append("-t")

    command.extend(config.extra_args)
    return command


def run_simulation(config: SimulationConfig) -> SimulationResult:
    command = build_forge_command(config)

    start = time.perf_counter()
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=config.timeout_seconds,
        check=False,
    )
    duration_seconds = time.perf_counter() - start

    result = SimulationResult(
        command=command,
        return_code=completed.returncode,
        stdout=completed.stdout,
        stderr=completed.stderr,
        winners=parse_winners(completed.stdout),
        duration_seconds=duration_seconds,
        config=config,
    )

    if config.output_directory:
        write_result_bundle(result, config.output_directory)

    return result


def write_result_bundle(result: SimulationResult, output_directory: Path) -> None:
    output_directory.mkdir(parents=True, exist_ok=True)

    (output_directory / "raw_stdout.txt").write_text(result.stdout, encoding="utf-8")
    (output_directory / "raw_stderr.txt").write_text(result.stderr, encoding="utf-8")
    (output_directory / "result.json").write_text(
        json.dumps(result.to_jsonable(), indent=2),
        encoding="utf-8",
    )
