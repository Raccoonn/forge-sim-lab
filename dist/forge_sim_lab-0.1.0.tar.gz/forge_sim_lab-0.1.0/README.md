# Forge Sim Lab

Forge Sim Lab is a small desktop app and Python package for running headless AI-vs-AI simulations with [Card-Forge / Forge](https://github.com/Card-Forge/forge).

It gives you:

- a Tkinter desktop UI
- browse buttons for selecting the Forge JAR and deck directory
- support for 2 to 12 deck entries in a sim
- single-run mode
- batch/league mode that repeats simulations many times
- JSONL + summary output for later analysis
- a reusable Python wrapper around Forge's `sim` command

## What this expects

This project assumes you already have Forge installed and have a working JAR / launchable build that supports:

```bash
java -jar forge.jar sim ...
```

## Install

From the project root:

```bash
python -m pip install -e .
```

## Run the app

```bash
python -m forge_sim_lab
```

or:

```bash
forge-sim-lab
```

## Main workflow

1. Pick your `forge.jar`
2. Optionally pick a deck directory
3. Add 2-12 deck names or `.dck` filenames
4. Choose format, game count, match count, timeout, quiet mode, etc.
5. Run one simulation or a repeated league batch
6. Review summary + saved logs

## Deck inputs

Each deck row can be one of:

- a Forge deck name
- a `.dck` filename
- a relative path inside the deck directory

## Notes on multiplayer

The UI allows up to 12 deck entries to match your "6v6 worth of cardboard degeneracy" goal.

Whether a given Forge build behaves exactly how you want for every multiplayer format combination still depends on Forge itself. This app passes the deck list and flags through cleanly, captures results, and saves the raw output so it is easy to inspect what Forge actually did.

## Output

Each run can save:

- `raw_stdout.txt`
- `raw_stderr.txt`
- `result.json`
- `results.jsonl` for repeated league runs
- `summary.json`

## Suggested next steps

After you get this running, the natural follow-ons are:

- matchup matrix automation
- deck roster import from a CSV / text file
- richer log parsing
- plotting win rates and placements
- Gymnasium-style training wrapper for ML work
